<?php   
/*
Plugin Name: Side Slide Menu
Plugin URI: http://codecanyon.net/user/wp_workshop
Description: Modern and easy to use support helpdesk solution
Author: WP Workshop
Version: 1.0
Author URI: http://codecanyon.net/user/wp_workshop
Licence: GPLv2
*/

require dirname( __FILE__ ) . '/SideSlideMenu.class.php';

SideSlideMenu::init(__FILE__);

?>